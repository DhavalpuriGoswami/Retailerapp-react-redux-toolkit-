import { BrowserRouter, Routes, Route } from "react-router-dom";
import { useSelector } from "react-redux";
import Home from "./Pages/Home";
import Login from './Pages/Login'
import Signuppage from './Pages/Signuppage'

const AppRouts = (props) => {
  const { isLoggedIn } = useSelector((state) => state.users);
  console.log(isLoggedIn)

  return (
    <div>
      <BrowserRouter>
        <Routes>
          {isLoggedIn ? (
            <Route path="/">
              <Route index element={<Home />} />
            </Route>
          ) : (
            <>
              <Route path="/" element={<Login />} />
              <Route path="/signup" element={<Signuppage />} />
            </>
          )}
        </Routes>
      </BrowserRouter>
    </div>
  );
};

export default AppRouts;