import React, { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import {
  Paper,
  Typography,
  List,
  ListItem,
  ListItemText,
  CircularProgress,
  AppBar,
  Toolbar,
  Button,
  Divider,
  IconButton,
} from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import { deleteProduct, getProducts } from "../apis/productsApi";
import { logoutUser } from "../store/slice/User-slice";
import ProductModal from "../Compo/ProductModal";
const ProductList = () => {
  const [isUpdatingProduct, setIsUpdatingProduct] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const { isFetchingProducts, products } = useSelector(
    (state) => state.products
  );
  console.log(isFetchingProducts);
  const { user } = useSelector((state) => state.users);
  console.log(user);
  const dispatch = useDispatch();
  const handleLogout = () => {
    dispatch(logoutUser());
  };
  const handleProductClick = (product) => {
    setSelectedProduct(product);
    setIsModalOpen(true);
  };
  useEffect(() => {
    if (user && user?.userId) dispatch(getProducts(user.userId));
  }, [dispatch, user]);
  if (isFetchingProducts) {
    return (
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "200px",
        }}
      >
        <CircularProgress />
      </div>
    );
  }
  const handleDeleteProduct = (product) => {
    debugger
    if (product?._id && user?.userId) {
      const payload = { productId: product._id };
      dispatch(deleteProduct(payload)).then(() =>
        dispatch(getProducts(user.userId))
      );
    }
  };
  return (
    <>
      <AppBar position="static">
        <Toolbar style={{ display: "flex", justifyContent: "flex-end" }}>
          <Button
            color="inherit"
            onClick={() => {
              setIsUpdatingProduct(false);
              setIsModalOpen(true);
              setSelectedProduct(null);
            }}
          >
            Add Product
          </Button>
          <Button color="inherit" onClick={handleLogout}>
            Logout
          </Button>
        </Toolbar>
      </AppBar>
      <Paper
        elevation={1}
        style={{
          padding: "16px",
          marginTop: "20px",
          maxWidth: "600px",
          margin: "auto",
          textAlign: "center",
        }}
      >
        <Typography variant="h6" gutterBottom>
          Product List
        </Typography>
        <List>
          {products?.length &&
            products?.map((product, index) => (
              <React.Fragment key={product._id}>
                <ListItem>
                  <ListItemText
                    primary={product.name}
                    secondary={
                      <React.Fragment>
                        <Typography
                          component="span"
                          variant="body2"
                          color="textPrimary"
                        >
                          Price: ${product.price}
                        </Typography>
                        <br />
                        {product.description}
                      </React.Fragment>
                    }
                    onClick={() => {
                      setIsUpdatingProduct(true);
                        handleProductClick(product);
                    }}
                    style={{ cursor: "pointer" }}
                  />
                  <IconButton
                    edge="end"
                    aria-label="delete"
                     onClick={() => handleDeleteProduct(product)}
                  >
                    <DeleteIcon />
                  </IconButton>
                </ListItem>
                {index < products.length - 1 && <Divider />}
              </React.Fragment>
            ))}
        </List>
      </Paper>
      <ProductModal
        isModalOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        selectedProduct={selectedProduct}
        isUpdating={Boolean(selectedProduct)}
      />
    </>
  );
};

export default ProductList;
