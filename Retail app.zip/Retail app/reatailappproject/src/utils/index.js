import { POST,GET,DELETE,PUT } from "./api";
export const API = { POST, GET, PUT, DELETE };

