import { combineReducers, configureStore } from "@reduxjs/toolkit"
import { FLUSH, PURGE, PAUSE, PERSIST, REGISTER, REHYDRATE, persistReducer, persistStore } from "redux-persist";
import storage from "redux-persist/lib/storage";
import ProductSlice from "./slice/Product-slice";
import userSlice from "./slice/User-slice";


const persistConfig = {
  key: "root",
  storage,
  whitelist: [],
}

const userConfig = {
  key: "user",
  storage,
  whitelist: ["isLoggedIn", "user"]
}

const rootReducer = combineReducers({
  users: persistReducer(userConfig, userSlice.reducer),
  products: ProductSlice,
})

const persistedReducer = persistReducer(persistConfig, rootReducer)

const store = configureStore({
  reducer: persistedReducer,
  middleware: (getDefaultMiddleware) => getDefaultMiddleware({
    serializableCheck: {
      ignoreActions: [FLUSH, PURGE, PAUSE, PERSIST, REGISTER, REHYDRATE]
    }
  })
})

const persister = persistStore(store);

export default store;
export { persister };
export { userSlice };